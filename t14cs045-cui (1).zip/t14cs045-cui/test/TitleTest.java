import static org.junit.Assert.*;

import org.junit.Test;

public class TitleTest {

	@Test
	public void getdifのテスト()
	{
		Title title=new Title(80,24);
		assertEquals(0,title.getdif());
	}
}
