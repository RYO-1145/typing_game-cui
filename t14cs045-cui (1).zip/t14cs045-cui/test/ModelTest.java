import static org.junit.Assert.*;

import org.junit.Test;

public class ModelTest {

	@Test
	public void getAAのテスト()
	{
		Model model = new Model();
		String[] AA={"","","","","","","","","","","","","","","","",""};
		model.setallAA(AA);
		for(int i=0;i<17;i++)
			assertEquals(AA[i],model.getallAA(0,i));
	}
	
	public void getclpointのテスト()
	{
		Model model =new Model();
		assertEquals(0,model.getclpoint());
	}
	
	public void getmisspointのテスト()
	{
		Model model =new Model();
		assertEquals(0,model.getmisspoint());
	}
	
	public void getQのテスト()
	{
		Model model =new Model();
		for(int i=0;i<16;i++)
			assertEquals(null,model.getQ(i));
	}
	
	public void getyaruoのテスト()
	{
		Model model = new Model();
		for(int i=0;i<17;i++)
			assertEquals(null,model.getyaruo(i));
	}
	
	public void getnumAAのテスト()
	{
		Model model = new Model();
		assertEquals(0,model.getnumAA());
	}
	
	public void getlankのテスト()
	{
		Model model = new Model();
		assertEquals(0,model.getlank());
	}
	
	public void getmoneyのテスト()
	{
		Model model = new Model();
		for(int i=0;i<17;i++)
			assertEquals(null,model.getmoney());
	}
	
	public void getSSRのテスト()
	{
		Model model = new Model();
		for(int i=0;i<4;i++)
			assertEquals("0",model.getSSR(i));
	}
	
	public void getlanknameのテスト()
	{
		Model model = new Model();
		for(int i=0;i<4;i++)
			assertEquals(null,model.getlankname(i));
	}
	
	public void getscoreのテスト()
	{
		Model model = new Model();
		model.setscore();
		for(int i=0;i<8;i++)
		{
			if(i!=3)
				assertEquals("0",model.getscore(i));
			else
				assertEquals("0円",model.getscore(i));
		}
	}
}
