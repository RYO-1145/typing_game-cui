

public class ConsoleView {
	
	private Model model;
	String[][] screen;
	int width;
	int height;
	int t_width=0;
	int time=0;
	int ms=0;
	int ac=0;
	int gatya=0;
	int byt=0;
	int lank=0;
	String[] word=new String[16];
	String[] ran=new String[16];
	String[] card=new String[4];
	String[] AA=new String[17];
	String[] sr;
	String[] reat={"SSR","SR","R","C"};
	
	public ConsoleView(Model m,int _width,int _height)
	{
		this(_width,_height);
		width=_width;
		height=_height;
		model=m;
		model.Q();
		NewQues();
	}
	
	public ConsoleView(int _width, int _height) {
		// TODO 自動生成されたコンス・スタブ
		screen = new String[_height][_width];
	}

	void ConsoleViewbreak(){screen=null;}
	
	void clear()
	{
		for(int i=0;i<24;i++){
			for(int j=0;j<80;j++)
				screen[i][j]=" ";
		}
	}
	
	public void setall()
	{
		buildquadrangle(1,1,28,22);
		buildquadrangle(30,8,49,12);
		buildquadrangle(30,18,49,22);
		buildquadrangle(51,1,78,22);
		
		for(int i=0;i<16;i++)
			screen[10][32+i]=ran[i];
		if(t_width==0){
			for(int i=0;i<16;i++)
				word[i]=" ";
		}
		
		put("残り時間:",4,57,8);
		put(String.valueOf(120-time),4,66,(String.valueOf(120-time)).length()+1);
		put("Answer :",6,57,8);
		put("Miss   :",8,57,8);
		put("課金額 :",10,57,8);
		put(String.valueOf(model.getclpoint()),6,65,(String.valueOf(model.getclpoint())).length());
		put(String.valueOf(model.getmisspoint()),8,65,(String.valueOf(model.getmisspoint())).length());
		put(String.valueOf(model.getmoney()),10,65,(String.valueOf(model.getmoney())).length());
		
		for(int i = 0;i<16;i++)
			put(word[i],20,32+i,1);
		
		if(ms!=0)
		{
			for(int i=0;i<6;i++)
				put(model.getyaruo(11-i-6),21-i,53,21);
			ms--;
		}
		else
		{
			for(int i=0;i<6;i++)
				put(model.getyaruo(11-i),21-i,53,21);
		}
		
		put("SSR    :",12,57,8);
		put("SR     :",13,57,8);
		put("R      :",14,57,8);
		put("C      :",15,57,8);
		
		model.setSSR();
		for(int i=0;i<4;i++)
		{
			card[i]=model.getSSR(i);
			put(card[i],12+i,65,card[i].length());
		}
		if(ac==1)
		{
				for(int i=0;i<17;i++)
					AA[i]=model.getAA(i);
			for(int i=0;i<26;i++)
				screen[21-gatya][2+i]="@";
			if(gatya>2&&gatya<20)
				for(int i=0;i<gatya-2;i++)
				{
					sr=AA[16-i].split("");
					for(int j=0;j<sr.length;j++)
					{
						if(sr[j].getBytes().length!=1)
							byt+=2;
						else
							byt++;
					}
					if(byt<3)
					{
						put(" ",19-i,4,1);
						byt=0;
					}
					else
					{
						put(AA[16-i],19-i,2,byt);
						byt=0;
					}
					lank=model.getlank();
					put(reat[lank-1],21,13,reat[lank-1].length());
				}
			gatya++;
			if(gatya>19)
			{
				model.setallAA(AA);
				gatya=0;
				ac=0;
			}
		}
	}
		
	public void update(int t){
		time=t;
		clear();
		setall();
		paint();
	}
	
	void buildquadrangle(int x,int y,int w,int h)
	{
		for(int i=y;i<h+1;i++){
			for(int j=x;j<w+1;j++){
				if(i==y||i==h)
					screen[i][j]="#";
			}
			screen[i][x]="#";
			screen[i][w]="#";
		}
	}
	void put(String x,int h,int w,int wordnum)
	{
		screen[h][w]=x;
		for(int i=0;i<wordnum-1;i++)
			screen[h][w+1+i]="";
	}
	
	void line(String event)
	{
		if(ran[t_width].equals(event)){
			word[t_width]=event;
			t_width++;
		}else
		{
			model.plusmisspoint();
			ms=5;
		}
		if(t_width>15){
			model.plusclpoint();
			model.Q();
			NewQues();
			t_width=0;
		}
	}
	
	public void NewQues(){
		for(int i=0;i<16;i++)
			ran[i]=model.getQ(i);
	}
	
	public void acplus(){ac++;}
	
	void paint()
	{
		for(int i=0;i<24;i++){
			for(int j=0;j<80;j++){
				System.out.print(screen[i][j]);
			}
			System.out.println();
		}
	}	

}
