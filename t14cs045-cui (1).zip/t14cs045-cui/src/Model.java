import java.io.IOException;

public class Model {
	private ConsoleView view;
	private ConsoleController controller;
	private Title title;
	private end end;
	private Ran random;
	private Ran gatyagatya;
	private Ran ranAA;
	private FileRead FILE;
	private FileRead FILEyaruo;
	private FileRead FILEAA;
	private int miss=0;
	private int cl=0;
	private int tt=0;
	private int dif=0;
	private int money=0;
	private int moneyif=0;
	private int ssr=0;
	private int sr=0;
	private int r=0;
	private int c=0;
	private int op=0;
	private int mtime=0;
	private int time=0;
	private int lank=0;
	private int x=0;
	private int[] lan=new int[10];
	private String[] book=new String[36];
	private String[] question=new String[16];
	private String[] yaruo=new String[12];
	private String[] scr=new String[8];
	private String[] getAA=new String[17];
	private String[][] allAA=new String[20][17];
	private String[] cardlist=new String[4];
	
	public Model(){
		controller = new ConsoleController(this);
		gatyagatya = new Ran(99);
		FILE = new FileRead("words.txt",36);
		FILEyaruo = new FileRead("yaruo.txt",12);
		FILE.FileReader();
		FILEyaruo.FileReader();
		for(int i=0;i<36;i++)
			book[i]=FILE.getwords(i);
		for(int i=0;i<12;i++)
			yaruo[i]=FILEyaruo.getwords(i);
		view = new ConsoleView(this,80,24);
		end = new end(this,80,24);
		title = new Title(this,80,24);
	}
	
	public synchronized void process(String event) {
		if (event.equals("TIME_ELAPSED"))
		{
			if(tt==1)
			{
				mtime+=100;
				if(mtime==1000)
				{
					time++;
					mtime=0;
				}
				if(time==120)
					tt=2;
			}
		}
		else
		{
			if(tt==0)
				title.line(event);
			else if(tt==1)
				view.line(event);
			else if(tt==2)
				end.line(event);
		}
		if(tt==0)
			title.update();
		else if(tt==1)
		{
			if(op==0)
			{
				dif=title.getdif();
				Q();
				view.NewQues();
				op++;
			}
			view.update(time);
		}
		else if(tt==2)
			end.update();
	}

	public void plusmisspoint()
	{
		miss++;
		if(miss>99)
			tt=2;
	}
	public void plusclpoint()
	{
		cl++;
		if(dif==0)
		{
			money+=500;
			moneyif+=500;
		}
		else if(dif==1)
		{
			money+=750;
			moneyif+=750;
		}
		else if(dif==2)
		{
			money+=1000;
			moneyif+=1000;
		}
		gatya();
	}
	public void plustt(){tt++;}
	public int getmisspoint(){return miss;}
	public int getclpoint(){return cl;}
	
	public void Q()
	{
		if(dif==0)
			random=new Ran(10);
		else if(dif==1)
			random=new Ran(26);
		else if(dif==2)
			random=new Ran(36);
		for(int i=0;i<16;i++)
		{
			int b=random.Rand();
			if(dif==0)
				b+=26;
			question[i]=book[b];
		}
	}
	public String getQ(int i){return question[i];}
	public String getyaruo(int i){return yaruo[i];}
	
	public void gatya()
	{
		if(moneyif>999)
		{
			int x=gatyagatya.Rand();
			moneyif-=1000;
			if(x==59)
			{
				ssr++;
				FILEAA=new FileRead("SSRAA.txt",34);
				FILEAA.FileReader();
				ranAA = new Ran(1);
				int b=ranAA.Rand();
				for(int i=0;i<17;i++)
				{
					getAA[i]=FILEAA.getwords(i+17*b);
				}
				lank=1;
			}
			if(x<59)
			{
				c++;
				FILEAA=new FileRead("CAA.txt",561);
				FILEAA.FileReader();
				ranAA = new Ran(32);
				int b=ranAA.Rand();
				for(int i=0;i<17;i++)
				{
					getAA[i]=FILEAA.getwords(i+17*b);
				}
				lank=4;
			}
			if(x>59&&x<90)
			{
				r++;
				FILEAA=new FileRead("RAA.txt",170);
				FILEAA.FileReader();
				ranAA = new Ran(9);
				int b=ranAA.Rand();
				for(int i=0;i<17;i++)
				{
					getAA[i]=FILEAA.getwords(i+17*b);
				}
				lank=3;
			}
			if(x>90)
			{
				sr++;
				FILEAA=new FileRead("SRAA.txt",85);
				FILEAA.FileReader();
				ranAA = new Ran(4);
				int b=ranAA.Rand();
				for(int i=0;i<17;i++)
					getAA[i]=FILEAA.getwords(i+17*b);
				lank=2;
			}
			view.acplus();
		}
	}
	public void setallAA(String[] AA)
	{
		lan[x]=lank;
		for(int i=0;i<17;i++)
			allAA[x][i]=AA[i];
		x++;
	}
	public String getAA(int i){return getAA[i];}
	public int getnumAA(){return x;}
	public String getallAA(int i,int j){return allAA[i][j];}
	public int getlank(){return lank;}
	public int getmoney(){return money;}
	public void setSSR()
	{
		cardlist[0]=String.valueOf(ssr);
		cardlist[1]=String.valueOf(sr);
		cardlist[2]=String.valueOf(r);
		cardlist[3]=String.valueOf(c);
	}
	public String getSSR(int i){return cardlist[i];}
	
	public void setscore()
	{
		scr[0]=String.valueOf(cl*1000+miss*(-100)+ssr*10000+sr*5000+r*1000+c*100);
		scr[1]=String.valueOf(cl);
		scr[2]=String.valueOf(miss);
		scr[3]=String.valueOf(money)+"円";
		scr[4]=String.valueOf(ssr);
		scr[5]=String.valueOf(sr);
		scr[6]=String.valueOf(r);
		scr[7]=String.valueOf(c);
	}
	public String getscore(int i){return scr[i];}
	public int getlankname(int i){return lan[i];}
	
	public void run() throws InterruptedException, IOException
	{
		controller.run();
	}
	
	public void reset()
	{
		controller = new ConsoleController(this);
		gatyagatya = new Ran(99);
		FILE = new FileRead("words.txt",36);
		FILEyaruo = new FileRead("yaruo.txt",12);
		FILE.FileReader();
		FILEyaruo.FileReader();
		for(int i=0;i<36;i++)
			book[i]=FILE.getwords(i);
		for(int i=0;i<12;i++)
			yaruo[i]=FILEyaruo.getwords(i);
		view = new ConsoleView(this,80,24);
		end = new end(this,80,24);
		title = new Title(this,80,24);
		dif=0;
		tt=0;
		ssr=0;
		sr=0;
		r=0;
		c=0;
		money=0;
		moneyif=0;
		cl=0;
		miss=0;
		op=0;
		mtime=0;
		time=0;
		x=0;
		lank=0;
	}
	
	public static void main(String[] arg) throws InterruptedException, IOException
	{
		Model model=new Model();
		model.run();
	}
}