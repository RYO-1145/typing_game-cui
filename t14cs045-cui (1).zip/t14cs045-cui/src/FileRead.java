


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class FileRead {
	private String filename;
	private int i=0;
	private int num;
	private String[] words;
	public FileRead(String _filename,int _num)
	{
		filename=_filename;
		num=_num;
		words=new String[num];
	}

 public void FileReader() {
	 
	 i=0; 
	 String[] strarray = new String[num];
      
	 try{
		 File file = new File(filename);
		 
		 BufferedReader br = new BufferedReader(new FileReader(file));
       
		 String str= null;
		 i=0;
		 while((str = br.readLine()) != null){
			 strarray[i]=str;
			 i = i +1;            
		 }
		 for(i=0;i<num;i++)
			 words[i]=strarray[i];

		 br.close();
       
              
	 }catch(FileNotFoundException e){
		 System.out.println(e);
	 }catch(IOException e){
		 System.out.println(e);
	 }
 }
 
 	void print()
 	{
 		for(int i=0;i<num;i++){
 			System.out.print(words[i]);
 			System.out.print(" ");
 		}
 	}
 
 	String getwords(int i){return words[i];}

}
