import java.util.Random;
public class Ran {
	private int r;
	public Ran(int _r){r=_r;}
	public int Rand(){
		Random rnd = new Random();
	      int num = rnd.nextInt(r);
	       return num;
	  }

}
