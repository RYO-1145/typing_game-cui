
public class Title {
	private Model model;
	private FileRead titlefile;
	String[][] screen;
	int width;
	int height;
	int dif=0;
	String[] word=new String[16];
	String[] ran=new String[16];
	String[] titleAA=new String[20];
	
	public Title(Model m,int _width,int _height)
	{
		this(_width,_height);
		width=_width;
		height=_height;
		model=m;
	}
	
	public Title(int _width, int _height) {
		// TODO 自動生成されたコンス・スタブ
		screen = new String[_height][_width];
		titlefile=new FileRead("title.txt",20);
		titlefile.FileReader();
		for(int i=0;i<20;i++)
			titleAA[i]=titlefile.getwords(i);
	}

	void Titlebreak(){screen=null;}
	
	void clear()
	{
		for(int i=0;i<24;i++){
			for(int j=0;j<80;j++)
				put(" ",i,j,1);
		}
	}
	void setall()
	{
		buildquadrangle(29,3,52,8);
		put("課金騎兵コンリ",5,34,14);
		put("～限度額を越えて行け～",6,30,22);
		
		buildquadrangle(35,13,46,19);
		put(">",15+dif,37,1);
		put("<",15+dif,44,1);
		put(" EASY ",15,38,6);
		put("NORMAL",16,38,6);
		put(" HARD ",17,38,6);
		put("W:上 S:下 T:決定",22,33,16);
		for(int i=0;i<12;i++)
		{
			put(titleAA[i],12+i,3,22);
			if(i<8)
				put(titleAA[i+12],16+i,49,30);
		}
	}
	
	void buildquadrangle(int x,int y,int w,int h)
	{
		for(int i=y;i<h+1;i++){
			for(int j=x;j<w+1;j++){
				if(i==y||i==h)
					screen[i][j]="#";
			}
			screen[i][x]="#";
			screen[i][w]="#";
		}
	}
	
	public void put(String x,int h,int w,int wordnum)
	{
		screen[h][w]=x;
		for(int i=0;i<wordnum-1;i++)
			screen[h][w+1+i]="";
	}
	
	public void update(){
		clear();
		setall();
		paint();
	}
		
	void line(String event)
	{
		if(event.equals("w"))
		{
			if(dif>0)
				dif--;
		}else if(event.equals("s"))
		{
			if(dif<2)
				dif++;
		}else if(event.equals("t"))
			model.plustt();
		
		else
			System.out.println(event);
	}
	
	public int getdif(){return dif;}
	
	void paint()
	{
		for(int i=0;i<24;i++){
			for(int j=0;j<80;j++){
				System.out.print(screen[i][j]);
			}
			System.out.println();
		}
	}	
}
