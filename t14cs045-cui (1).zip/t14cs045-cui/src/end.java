
public class end {
	private Model model;
	String[][] screen;
	int width;
	int height;
	int ops=0;
	int numAA=0;
	int AAst=0;
	int[] lank=new int[10];
	String[] scr=new String[8];
	String[][] allAA=new String[20][17];
	String[] sr;
	String[] lankAA={"SSR","SR","R","C"};
	
	public end(Model m,int _width,int _height)
	{
		this(_width,_height);
		width=_width;
		height=_height;
		model=m;
	}
	
	public end(int _width, int _height)
	{
		// TODO 自動生成されたコンス・スタブ
		screen = new String[_height][_width];
	}

	void Titlebreak(){screen=null;}
	
	void clear()
	{
		for(int i=0;i<24;i++){
			for(int j=0;j<80;j++)
				put(" ",i,j,1);
		}
	}
	
	void setall()
	{
		put("GAME  OVER",2,35,10);
		buildquadrangle(33,1,46,3);
		put("A:左 D:右 E:タイトルへ",23,37,22);
		buildquadrangle(1,11,16,22);
		put("RESULT",11,6,6);
		put("SCORE :",13,2,7);
		put("Answer:",14,2,7);
		put("Miss  :",15,2,7);
		put("課金額:"  ,16,2,7);
		put("SSR   :",17,2,7);
		put("SR    :",18,2,7);
		put("R     :",19,2,7);
		put("C     :",20,2,7);
		for(int i=0;i<8;i++)
			put(scr[i],13+i,9,scr[i].length());
		screen[16][15]="";
		
		if(model.getnumAA()!=0)
		{
				for(int i=0;i<17;i++)
				{
					int byt=0;
					sr=allAA[numAA][16-i].split("");
					for(int j=0;j<sr.length;j++)
					{
						if(sr[j].getBytes().length!=1)
							byt+=2;
						else
							byt++;
					}
					put(allAA[numAA][16-i],20-i,37,byt);
				}
					put(lankAA[lank[numAA]-1],22,46,3);
		}
	}
	
	void buildquadrangle(int x,int y,int w,int h)
	{
		for(int i=y;i<h+1;i++){
			for(int j=x;j<w+1;j++){
				if(i==y||i==h)
					screen[i][j]="#";
			}
			screen[i][x]="#";
			screen[i][w]="#";
		}
	}
	public void put(String x,int h,int w,int wordnum)
	{
		screen[h][w]=x;
		for(int i=0;i<wordnum-1;i++)
			screen[h][w+1+i]="";
	}
	
	public void update(){
		if(ops==0)
		{
			setallscore();
			ops=1;
		}
		AAst=model.getnumAA();
		for(int i=0;i<AAst;i++)
		{
			for(int j=0;j<17;j++)
				allAA[i][j]=model.getallAA(i,j);
			lank[i]=model.getlankname(i);
		}
		clear();
		setall();
		paint();
	}
		
	void line(String event)
	{
		if(event.equals("a"))
		{
			if(numAA!=0)
				numAA--;
			else
				numAA=model.getnumAA()-1;
		}
		if(event.equals("d"))
		{
			if(numAA!=model.getnumAA()-1)
				numAA++;
			else
				numAA=0;
		}
		if(event.equals("e"))
			model.reset();
	}
	
	public void setallscore()
	{
		model.setscore();
		for(int i=0;i<8;i++)
			scr[i]=model.getscore(i);
	}
	
	void paint()
	{
		for(int i=0;i<24;i++){
			for(int j=0;j<80;j++){
				System.out.print(screen[i][j]);
			}
			System.out.println();
		}
	}	
}
